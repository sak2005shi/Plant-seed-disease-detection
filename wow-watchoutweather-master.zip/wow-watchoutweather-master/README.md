# wow-watchoutweather
Weather API-based Website for real-time weather information with additional facilities.

Home Page
![image](https://user-images.githubusercontent.com/74554060/162771046-3e762b57-05b7-46a3-910c-3f227ce974d4.png)

link -  https://akkkanksha.github.io/wow-watchoutweather/
